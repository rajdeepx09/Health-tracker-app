# Decentralized Subscription Learning Platform

## Overview
A blockchain-based learning platform that allows instructors to create courses and students to subscribe using cryptocurrency.

## Features
- Course Creation
- Subscription Management
- Instructor Earnings Tracking
- Transparent Course Marketplace

## Smart Contract Functionality
- Create courses with title, description, and subscription fee
- Subscribe to courses for 30-day periods
- Withdraw instructor earnings
- Course activation/deactivation

## Prerequisites
- Solidity ^0.8.0
- MetaMask or Web3-compatible wallet
- Web3.js library
- OpenZeppelin Contracts library

## Frontend Setup
1. Deploy the Solidity smart contract
2. Replace `contractAddress` with your deployed contract address
3. Update `contractABI` with your contract's ABI
4. Ensure Web3.js is properly linked

## Deployment Steps
1. Deploy smart contract on Ethereum network
2. Configure frontend with contract details
3. Connect MetaMask wallet
4. Start using the platform

## Key Contract Methods
- `createCourse()`: Instructors create courses
- `subscribeToCourse()`: Students subscribe to courses
- `isSubscribed()`: Check subscription status
- `withdrawEarnings()`: Withdraw instructor earnings

## Security Considerations
- Fixed 30-day subscription period
- Prevents duplicate subscriptions
- Protects against reentrancy
- Instructor-only course management

## Future Improvements
- Multi-tier subscriptions
- Refund mechanisms
- Student reputation system
- Advanced course filtering

## Technologies Used
- Solidity
- Web3.js
- HTML5
- CSS3
- JavaScript
- Ethereum Blockchain

## Contributing
1. Fork the repository
2. Create your feature branch
3. Commit changes
4. Push to the branch
5. Create a Pull Request

## License
MIT License

## Contact
[Your Contact Information]